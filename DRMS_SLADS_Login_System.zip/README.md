# Digital Records Management System

SLADS Bagamoyo, Tanzania

The system includes a login page, dashboard and logout function.
